package id.co.telkomsigma.Diarium.util.qiscus.ui.base;

/**
 * Created by adicatur on 12/24/16.
 */

public interface Mvp {

    void showLoading();

    void dismissLoading();

    void showError(String error);

}
