package id.co.telkomsigma.Diarium.util.qiscus.util;

public class Constant {
    //public static String QISCUS_APP_ID = "ziv-nqsjtf0zdqf6kfk7s";
    public static String QISCUS_APP_ID = "xeno-guj3hhypxgmyxnxd"; //dari tama
//    public static String QISCUS_APP_ID = "ysham-sqlovq0y0w57lqj"; //dari tama
}
